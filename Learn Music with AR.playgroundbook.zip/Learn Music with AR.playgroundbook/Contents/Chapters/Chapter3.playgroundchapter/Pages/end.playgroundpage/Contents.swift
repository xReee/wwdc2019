//#-hidden-code
//  wwdcRenata
//
//  Created by RenataFaria on 15/03/17.
//  Copyright © 2017 RenataFaria. All rights reserved.
//

 //#-end-hidden-code

/*:
 ### That's all ! Thank you so much!
 
 ## Thanks:
  - **Textures.com** for the wood texture
  - **Autodesk** for the free student license of **Inventor**
  - **DANMITCH3LL** from **free-sound** for the notes sound
  - **Apple** for the music made on **garage band** for free
  - My friend **Pericles** for supporting me with music theory

  - Note:
    The content and assets of this playground were made by me and they are free for share, use and modify for anyone for any purpose.
 
 # Renata Faria Gomes
 ## WWDC 2019 - Scholarship Submission
 
*/

//#-code-completion(everything, hide)


